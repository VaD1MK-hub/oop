public class Transport {
    protected String vehicleNumber;
    protected int capacity;

    public Transport(String vehicleNumber, int capacity) {
        this.vehicleNumber = vehicleNumber;
        this.capacity = capacity;
    }

    public void boardPassenger(String passenger) {
        System.out.println("Метод boardPassenger не реализован для " + vehicleNumber);
    }

    public String getVehicleInfo() {
        return "Транспорт: " + vehicleNumber + ", Вместимость: " + capacity;
    }
}
