@FunctionalInterface
public interface PassengerAction {
    void execute(String passenger);

    default void greetPassenger(String passenger) {
        System.out.println("Здравствуйте, " + passenger + "!");
    }
}
