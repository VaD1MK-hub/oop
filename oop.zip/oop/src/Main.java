public class Main {
    public static void main(String[] args) {
        // Создание станций с различными временами прибытия
        Station station1 = new Station("Центральная", "2025-01-11 15:30:00");
        Station station2 = new Station("Вокзал", "2025-01-11 16:00:00");

        Bus bus1 = new Bus("A1", 2, "2025-01-11T14:00:00");
        Bus bus2 = new Bus("B2", 3, "2025-01-11T14:30:00");

        station1.addBus(bus1);
        station2.addBus(bus2);

        PassengerAction action = passenger -> System.out.println("Пассажир " + passenger + " заходит в автобус.");

        Stack<String> passengerStack1 = new MyStack<>();
        passengerStack1.push("Иван");
        passengerStack1.push("Мария");
        passengerStack1.push("Анна");

        System.out.println("\nИнформация о первом автобусе:");
        while (!passengerStack1.empty()) {
            String passenger = passengerStack1.pop();
            bus1.boardPassenger(passenger, action);
        }

        System.out.println("\nИнформация о станции 1:");
        System.out.println(station1.getArrivalTimeInfo());
        System.out.println(station1.getTimeUntilArrival());
        System.out.println("Дней до прибытия на станцию 1: " + station1.getDaysUntilArrival());
        System.out.println(station1.getPeriodUntilArrival());
        System.out.println(bus1.getTripDuration());

        System.out.println("\nИнформация о втором автобусе:");
        Stack<String> passengerStack2 = new MyStack<>();
        passengerStack2.push("Петр");
        passengerStack2.push("Ольга");
        passengerStack2.push("Сергей");

        while (!passengerStack2.empty()) {
            String passenger = passengerStack2.pop();
            bus2.boardPassenger(passenger, action);
        }

        System.out.println("\nИнформация о станции 2:");
        System.out.println(station2.getArrivalTimeInfo());
        System.out.println(station2.getTimeUntilArrival());
        System.out.println("Дней до прибытия на станцию 2: " + station2.getDaysUntilArrival());
        System.out.println(station2.getPeriodUntilArrival());
        System.out.println(bus2.getTripDuration());
    }
}
